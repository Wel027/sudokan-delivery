const CONFIG = {
  whatsapp: '351900000000',   // número do restaurante, com indicativo, sem '+'
  deliveryFee: 2.50,
  minOrderDelivery: 15,
};

const $ = (s) => document.querySelector(s);
const $$ = (s) => document.querySelectorAll(s);
const fmt = (n) => n.toLocaleString('pt-PT', { style: 'currency', currency: 'EUR' });
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => (
  { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
));

const state = {
  mode: localStorage.getItem('sudokan-mode') || 'delivery',
  category: 'Todos',
  cart: JSON.parse(localStorage.getItem('sudokan-cart') || '[]'),
  current: null,
  qty: 1,
  trackerTimers: [],
};

const saveCart = () => localStorage.setItem('sudokan-cart', JSON.stringify(state.cart));
const cartCount = () => state.cart.reduce((s, i) => s + i.qty, 0);
const subtotal = () => state.cart.reduce((s, i) => s + i.unit * i.qty, 0);
const fee = () => (state.mode === 'delivery' ? CONFIG.deliveryFee : 0);
const itemImg = (p) => (p.img
  ? `<img src="${esc(p.img)}" alt="${esc(p.name)}" loading="lazy">`
  : '🍣');

function toast(msg) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => t.classList.remove('show'), 1800);
}

function showView(name) {
  ['menu', 'checkout', 'confirm'].forEach((v) =>
    $('#view-' + v).classList.toggle('hidden', v !== name));
  $('#categories').classList.toggle('hidden', name !== 'menu');
  window.scrollTo(0, 0);
  renderCart();
}

/* Tipo de pedido */
function setMode(mode) {
  state.mode = mode;
  localStorage.setItem('sudokan-mode', mode);
  $$('#mode-toggle button').forEach((b) => {
    const on = b.dataset.mode === mode;
    b.classList.toggle('active', on);
    b.setAttribute('aria-selected', on);
  });
  $('#address-block').classList.toggle('hidden', mode !== 'delivery');
  if (!$('#view-checkout').classList.contains('hidden')) renderCheckout();
}
$('#mode-toggle').addEventListener('click', (e) => {
  const b = e.target.closest('button');
  if (b) setMode(b.dataset.mode);
});

/* Categorias */
function renderCategories() {
  $('#categories').innerHTML = ['Todos', ...MENU.categories].map((c) =>
    `<button type="button" class="chip ${c === state.category ? 'active' : ''}" data-cat="${esc(c)}">${esc(c)}</button>`
  ).join('');
}
$('#categories').addEventListener('click', (e) => {
  const b = e.target.closest('[data-cat]');
  if (!b) return;
  state.category = b.dataset.cat;
  renderCategories();
  renderMenu();
  b.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
});

/* Menu */
function renderMenu() {
  const items = MENU.products.filter((p) =>
    state.category === 'Todos' || p.cat === state.category);
  $('#menu').innerHTML = items.map((p) => `
    <article class="card" data-id="${esc(p.id)}" tabindex="0">
      <div class="card-img">
        ${itemImg(p)}
        ${p.tags && p.tags[0] ? `<span class="badge">${esc(p.tags[0])}</span>` : ''}
      </div>
      <div class="card-body">
        <h3>${esc(p.name)}</h3>
        <p>${esc(p.desc || '')}</p>
        <div class="card-foot">
          <strong>${fmt(p.price)}</strong>
          <span class="add-btn" aria-hidden="true">+</span>
        </div>
      </div>
    </article>`).join('');
}
$('#menu').addEventListener('click', (e) => {
  const c = e.target.closest('.card');
  if (c) openProduct(c.dataset.id);
});
$('#menu').addEventListener('keydown', (e) => {
  if (e.key !== 'Enter') return;
  const c = e.target.closest('.card');
  if (c) openProduct(c.dataset.id);
});

/* Modal do produto */
function openProduct(id) {
  const p = MENU.products.find((x) => x.id === id);
  if (!p) return;
  state.current = p;
  state.qty = 1;
  const removable = p.removable || [];
  const extras = p.extras || [];

  $('#modal-body').innerHTML = `
    <div class="modal-img">${itemImg(p)}</div>
    <h2 id="modal-title">${esc(p.name)}</h2>
    <p class="muted">${esc(p.desc || '')}</p>
    ${removable.length ? `
      <fieldset>
        <legend>Retirar ingredientes</legend>
        ${removable.map((r) => `
          <label class="opt">
            <input type="checkbox" name="remove" value="${esc(r)}">
            <span>${esc(r)}</span>
          </label>`).join('')}
      </fieldset>` : ''}
    ${extras.length ? `
      <fieldset>
        <legend>Extras</legend>
        ${extras.map((x) => `
          <label class="opt">
            <input type="checkbox" name="extra" value="${esc(x.name)}" data-price="${x.price}">
            <span>${esc(x.name)}</span>
            <em>+${fmt(x.price)}</em>
          </label>`).join('')}
      </fieldset>` : ''}
    <label class="field">Observações
      <textarea id="note" rows="2" maxlength="140" placeholder="Ex.: sem wasabi, bem frio"></textarea>
    </label>`;

  $('#qty').textContent = 1;
  updateModalPrice();
  $('#product-modal').classList.remove('hidden');
  document.body.classList.add('lock');
}

function unitPrice() {
  const extras = [...$$('#modal-body input[name=extra]:checked')]
    .reduce((s, i) => s + Number(i.dataset.price), 0);
  return state.current.price + extras;
}

function updateModalPrice() {
  $('#qty').textContent = state.qty;
  $('#add-btn').textContent = `Adicionar · ${fmt(unitPrice() * state.qty)}`;
}

function closeModal() {
  $('#product-modal').classList.add('hidden');
  document.body.classList.remove('lock');
}

$('#modal-body').addEventListener('change', updateModalPrice);
$('#plus').onclick = () => { state.qty = Math.min(state.qty + 1, 20); updateModalPrice(); };
$('#minus').onclick = () => { state.qty = Math.max(1, state.qty - 1); updateModalPrice(); };
$('#close-modal').onclick = closeModal;
$('#product-modal').addEventListener('click', (e) => {
  if (e.target.id === 'product-modal') closeModal();
});
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') closeModal();
});

$('#add-btn').onclick = () => {
  const p = state.current;
  const removed = [...$$('#modal-body input[name=remove]:checked')].map((i) => i.value).sort();
  const extras = [...$$('#modal-body input[name=extra]:checked')].map((i) => i.value).sort();
  const note = $('#note').value.trim();
  const unit = unitPrice();
  const key = [p.id, removed.join('|'), extras.join('|'), note].join('::');

  const existing = state.cart.find((i) => i.key === key);
  if (existing) existing.qty += state.qty;
  else state.cart.push({ key, id: p.id, name: p.name, unit, qty: state.qty, removed, extras, note });

  saveCart();
  closeModal();
  renderCart();
  toast('Adicionado ao carrinho');
};

/* Carrinho (FAB) */
function renderCart() {
  const n = cartCount();
  const onMenu = !$('#view-menu').classList.contains('hidden');
  $('#cart-fab').classList.toggle('hidden', !(n > 0 && onMenu));
  $('#cart-count').textContent = `${n} ${n === 1 ? 'item' : 'itens'}`;
  $('#cart-total').textContent = fmt(subtotal());
}
$('#cart-fab').onclick = () => { showView('checkout'); renderCheckout(); };
document.querySelector('[data-back]').onclick = () => showView('menu');

/* Checkout */
function renderCheckout() {
  const form = $('#checkout-form');
  if (!state.cart.length) {
    $('#cart-list').innerHTML = '<p class="muted">O carrinho está vazio.</p>';
    $('#summary').innerHTML = '';
    form.classList.add('hidden');
    $('#form-warning').classList.add('hidden');
    return;
  }
  form.classList.remove('hidden');

  $('#cart-list').innerHTML = `<div class="summary">${state.cart.map((i) => `
    <div class="cart-item">
      <div class="info">
        <strong>${esc(i.name)}</strong>
        ${i.removed.length ? `<small>Sem: ${esc(i.removed.join(', '))}</small>` : ''}
        ${i.extras.length ? `<small>Extras: ${esc(i.extras.join(', '))}</small>` : ''}
        ${i.note ? `<small>Obs.: ${esc(i.note)}</small>` : ''}
        <strong>${fmt(i.unit * i.qty)}</strong>
      </div>
      <div class="qty">
        <button type="button" data-act="dec" data-key="${esc(i.key)}" aria-label="Diminuir">−</button>
        <span>${i.qty}</span>
        <button type="button" data-act="inc" data-key="${esc(i.key)}" aria-label="Aumentar">+</button>
      </div>
      <button type="button" class="del" data-act="del" data-key="${esc(i.key)}">Remover</button>
    </div>`).join('')}</div>`;

  const sub = subtotal();
  const f = fee();
  $('#summary').innerHTML = `
    <div class="row"><span>Subtotal</span><span>${fmt(sub)}</span></div>
    <div class="row"><span>Taxa de entrega</span><span>${state.mode === 'delivery' ? fmt(f) : 'Grátis'}</span></div>
    <div class="row total"><span>Total</span><span>${fmt(sub + f)}</span></div>`;

  const belowMin = state.mode === 'delivery' && sub < CONFIG.minOrderDelivery;
  const warn = $('#form-warning');
  warn.classList.toggle('hidden', !belowMin);
  warn.textContent = belowMin
    ? `Pedido mínimo para entrega: ${fmt(CONFIG.minOrderDelivery)}. Faltam ${fmt(CONFIG.minOrderDelivery - sub)}.`
    : '';
}

$('#cart-list').addEventListener('click', (e) => {
  const b = e.target.closest('[data-act]');
  if (!b) return;
  const item = state.cart.find((i) => i.key === b.dataset.key);
  if (!item) return;
  if (b.dataset.act === 'inc') item.qty = Math.min(item.qty + 1, 20);
  if (b.dataset.act === 'dec') item.qty = Math.max(1, item.qty - 1);
  if (b.dataset.act === 'del') state.cart = state.cart.filter((i) => i !== item);
  saveCart();
  renderCheckout();
  renderCart();
});

/* Submissão e WhatsApp */
const PT_MOBILE = /^9\d{8}$/;
const POSTAL = /^\d{4}-\d{3}$/;
const EMAIL = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;

function validate(f) {
  const errs = {};
  const phone = f.phone.replace(/[\s+]/g, '').replace(/^351/, '');
  if (f.name.trim().length < 2) errs.name = 'Indique o seu nome.';
  if (!PT_MOBILE.test(phone)) errs.phone = 'Telemóvel inválido (ex: 912345678).';
  if (f.email && f.email.trim() && !EMAIL.test(f.email)) errs.email = 'Email inválido.';

  if (state.mode === 'delivery') {
    if (!f.street.trim()) errs.street = 'Indique a rua.';
    if (!f.number.trim()) errs.number = 'Indique o número.';
    if (!POSTAL.test(f.postal)) errs.postal = 'Código postal inválido (0000-000).';
    if (!f.city.trim()) errs.city = 'Indique a localidade.';
  }

  const paymentSelected = $$('#checkout-form input[name=payment]:checked').length > 0;
  if (!paymentSelected) errs.payment = 'Selecione um método de pagamento.';

  return errs;
}

$('#checkout-form').addEventListener('submit', (e) => {
  e.preventDefault();
  const data = Object.fromEntries(new FormData(e.target));
  const errs = validate(data);

  $$('#checkout-form .error').forEach((el) => {
    el.textContent = errs[el.dataset.for] || '';
  });

  if (Object.keys(errs).length) {
    toast('Por favor, corrija os erros no formulário.');
    return;
  }

  const sub = subtotal();
  const f = fee();
  const total = sub + f;

  let msg = `🍣 *NOVO PEDIDO - SUDOKAN* 🍣\n\n`;
  msg += `*Tipo:* ${state.mode === 'delivery' ? 'Entrega ao Domicílio' : 'Takeaway'}\n`;
  msg += `*Cliente:* ${data.name}\n`;
  msg += `*Telemóvel:* ${data.phone}\n`;
  if (data.email) msg += `*Email:* ${data.email}\n`;

  if (state.mode === 'delivery') {
    msg += `*Morada:* ${data.street}, nº ${data.number}${data.floor ? ' (' + data.floor + ')' : ''}\n`;
    msg += `*Localidade:* ${data.postal} ${data.city}\n`;
    if (data.deliveryNotes) msg += `*Notas estafeta:* ${data.deliveryNotes}\n`;
  }

  msg += `*Pagamento:* ${data.payment}\n\n*Itens:* \n`;
  state.cart.forEach((i) => {
    msg += `• ${i.qty}x ${i.name} (${fmt(i.unit * i.qty)})\n`;
    if (i.removed.length) msg += `  Sem: ${i.removed.join(', ')}\n`;
    if (i.extras.length) msg += `  Extras: ${i.extras.join(', ')}\n`;
    if (i.note) msg += `  Obs: ${i.note}\n`;
  });

  msg += `\n*Subtotal:* ${fmt(sub)}\n`;
  if (state.mode === 'delivery') msg += `*Taxa de entrega:* ${fmt(f)}
`;
  msg += `*TOTAL:* ${fmt(total)}`;

  const waUrl = `https://wa.me/${CONFIG.whatsapp}?text=${encodeURIComponent(msg)}`;
  $('#wa-btn.wa').href = waUrl;

  $('#confirm-title.muted, #confirm-title').textContent = 'Pedido pronto a enviar!';
  $('#confirm-sub').textContent = 'O seu carrinho foi processado. Clique abaixo para enviar o pedido diretamente para o WhatsApp do SUDOKAN.';
  
  $('#confirm-summary.summary').innerHTML = `
    <div class="row"><span>Cliente</span><span>${esc(data.name)}</span></div>
    <div class="row"><span>Total a pagar</span><strong>${fmt(total)}</strong></div>
  `;

  showView('confirm');
  state.cart = [];
  saveCart();
  renderCart();
});

$('#new-order').onclick = () => {
  showView('menu');
};

// Inicialização
document.addEventListener('DOMContentLoaded', () => {
  setMode(state.mode);
  renderCategories();
  renderMenu();
  renderCart();
});
